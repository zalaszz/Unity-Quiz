[System.Serializable]
public class QuestionAnswer{
    public string Question;
    public string[] Answers;
    public int CorrectAnswer;
}